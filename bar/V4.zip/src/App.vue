<template>
  <div>
    <!-- <button><router-link to="login">登录</router-link></button> -->
    <router-view></router-view>
  </div>
</template>

<script setup></script>

<style scoped></style>
