<template>
  <div>
    <el-container>
      <component-aside v-if="screenWidth > 768"></component-aside>
      <el-container style="flex-direction: column">
        <component-header v-if="screenWidth <= 768"></component-header>
        <el-scrollbar class="el-main-scrollbar">
          <el-main>
            <!-- 如果history为[]则显示首页提示组件 -->
            <component-index v-if="history.length == 0"></component-index>
            <!-- 
              xs（特小）：小于 576px 宽度的设备或窗口。
              sm（小）：576px 或更大宽度的设备或窗口。
              md（中）：768px 或更大宽度的设备或窗口。
              lg（大）：992px 或更大宽度的设备或窗口。
              xl（特大）：1200px 或更大宽度的设备或窗口。
             -->
            <component-content></component-content>
            <component-footer></component-footer>
          </el-main>
        </el-scrollbar>
      </el-container>
    </el-container>
  </div>
</template>

<script setup>
import { Plus, ChatSquare, Delete, Check, Close } from "@element-plus/icons-vue";
import { PlusOutlined, EditOutlined } from "@ant-design/icons-vue";
import { onBeforeMount, onBeforeUnmount, onMounted, ref, nextTick, provide } from "vue";
import ComponentAside from "./child/Component-Aside.vue";
import ComponentHeader from "./child/Component-Header.vue";
import ComponentContent from "./child/Component-Content.vue";
import ComponentFooter from "./child/Component-Footer.vue";
// import ComponentIndex from "./child/Component-Index.vue";

//<start> 实时监听屏幕宽度 大于768px时显示侧边栏
const screenWidth = ref(window.innerWidth);
const handleResize = () => {
  screenWidth.value = window.innerWidth;
};

onMounted(() => {
  window.addEventListener("resize", handleResize);
});

onBeforeUnmount(() => {
  window.removeEventListener("resize", handleResize);
});
//<end> 实时监听屏幕宽度

//变量声明
const activeIndex = ref(-1); //当前会话索引
const history = ref([]); //当前会话聊天记录

const deleteTitle = ref(-1); //删除会话索引

//新会话
const newChat = () => {
  console.log("newChat");
  history.value = [];
  activeIndex.value = -1;
  deleteTitle.value = -1;
};


//收集浏览器历史记录
const chatHistory = ref([]);
onBeforeMount(() => {
  chatHistory.value = JSON.parse(localStorage.getItem("chatHistory"));

  console.log(chatHistory.value);
});

//<start>子组件传值
//方法
provide("newChat", newChat);
//变量
provide("chatHistory", chatHistory);
provide("history", history);
provide("activeIndex", activeIndex);

//<end>子组件传值
</script>

<style scoped>
@media (width < 768px) {
  /* .el-aside {
    宽度少于768时aside会自动隐藏
    display: none;
  } */
  /* .el-header.el-header {
    display: flex;
  } */

  .el-main.el-main {
    width: auto;
  }

  .input-box.input-box {
    width: 95%;
    right: calc(100% / 2 - 95% / 2);
    bottom: 2vh;
  }
  .el-main-scrollbar {
    max-height: 90vh;
  }
}

.el-main {
  /* height: 90vh; */
  padding: 0;
  width: calc(100vw - 260px);
  /* padding:20px 0px 20px 0px; */
  overflow-x: hidden;
}

.el-main-scrollbar {
  height: 92vh;
}

.newButton {
  color: #ffffff;
  align-items: center;
}

.centered-menu-item {
  text-align: center;
}

.index-content .el-col {
  padding: 0.75rem;
  background-color: rgb(247, 247, 248);
  border-radius: 0.375rem;
}
</style>
