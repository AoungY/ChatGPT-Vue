<template>
  <el-footer>
    <div class="input-box">
      <el-input
        v-model="question"
        :autosize="{ minRows: 1, maxRows: 8 }"
        resize="none"
        type="textarea"
        placeholder="Send a message."
        class="el-textarea-input"
        @keydown.enter="handleEnterKey($event)"
      />
      <div class="send" @click="sendQuestion()">
        <span>
          <svg
            stroke="currentColor"
            fill="none"
            stroke-width="2"
            viewBox="0 0 24 24"
            stroke-linecap="round"
            stroke-linejoin="round"
            class="h-4 w-4 mr-1"
            height="1em"
            width="1em"
            xmlns="http://www.w3.org/2000/svg"
          >
            <line x1="22" y1="2" x2="11" y2="13"></line>
            <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
          </svg>
        </span>
      </div>
    </div>
  </el-footer>
</template>

<script setup>
import { inject,ref } from "vue";

//<start>获取父组件变量/方法
const history = inject("history");
const chatHistory = inject("chatHistory");
const activeIndex = inject("activeIndex");

//<end>获取父组件变量/方法
    const question = ref(""); //问题
const contextLength = ref(8); //上下文长度
//main
const sendQuestion = async () => {
  //发送问题不能为空
  if (question.value == "") {
    return;
  }
  if (activeIndex.value === -1) {
    console.log("new chat", activeIndex.value);

    history.value = [
      { role: "user", content: question.value },
      { role: "ai", content: "" },
    ];
    sendApi();

    chatHistory.value.push({
      title: "New Chat",
      history: history.value,
    });

    activeIndex.value = (chatHistory.value.length - 1).toString();
  } else {
    //旧会话
    history.value.push({ role: "user", content: question.value });
    history.value.push({ role: "ai", content: "" });
    sendApi();
  }
  question.value = "";
};

const sendApi = async () => {
  let data = history.value.slice(0, history.value.length - 1);
  const response = await fetch("/chatGPT", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data.splice(-contextLength.value)),
  });

  const reader = response.body.getReader();
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    // console.log(done, value, new TextDecoder("utf-8").decode(value));
    // 写法二：history.value[history.value.length - 1]["content"] += new TextDecoder("utf-8").decode(value);
    history.value.at(-1).content += new TextDecoder("utf-8").decode(value);
  }
  //如果histroy长度为2 则说明是新会话 需要从最后一个开始覆盖
  if (history.value.length === 2) {
    chatHistory.value.at(-1).history = history.value;
    getTitle(chatHistory.value.length - 1);
  } else chatHistory.value.at(activeIndex.value).history = history.value;
  //持久化 保存
  localStorage.setItem("chatHistory", JSON.stringify(chatHistory.value));
};
//向ChatGPT获得会话标题 并 设置
const getTitle = async (index) => {
  let data = chatHistory.value[index].history.slice(
    0,
    chatHistory.value[index].history.length
  );
  data.push({
    role: "user",
    content:
      "根据我们刚才以上的会话内容生成一个标题，token限制在10以内，只需回答标题内容即可",
  });
  console.log("setTitle", index, data);
  const response = await fetch("/chatGPT", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  });

  const reader = response.body.getReader();
  chatHistory.value[index].title = "";
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    if (new TextDecoder("utf-8").decode(value) === '"') continue;
    chatHistory.value[index].title += new TextDecoder("utf-8").decode(value);
  }
  localStorage.setItem("chatHistory", JSON.stringify(chatHistory.value));
};

//Enter 和 Shift+Enter的事件
const handleEnterKey = (event) => {
  //若同时按下shift键 则不触发
  if (event.shiftKey) return;
  sendQuestion();
  event.preventDefault(); //阻止默认事件
};
</script>

<style scoped>
.el-footer {
  display: flex;
  height: 10vh;
  padding: 0;
  position: fixed;
  bottom: 0px;
  width: 100vw;
  background-image: linear-gradient(to bottom, transparent 0%, white 40%);
  /* 设置层级高于main 渐变对main的滚动条一样生效 */
  z-index: 10;
}

.input-box {
  position: fixed;
  right: calc((100vw - 260px) / 2 - 65% / 2);
  bottom: 4.5vh;
  box-sizing: border-box;
  width: 65%;
  padding: 0.5rem 0.5rem;
  box-shadow: 0px 0px 5px 1px #ccc;
  height: fit-content;
  border-radius: 5px;
  display: flex;
  align-items: flex-end;
  gap: 0.5rem;
  background-color: #ffffff;
}
:deep(.el-textarea__inner) {
  box-shadow: none;
  border: none;
  padding: 0px 11px;
  font-size: 1.125rem;
  vertical-align: middle;
}
:deep(.el-textarea__inner):hover {
  border: none;
  box-shadow: none;
}

.el-textarea-input {
  flex: 1;
}

.send span {
  display: inline-block;
  margin-bottom: 2px;
  --color: rgb(186, 186, 181);
  border-radius: 4px;
  padding: 4px 4px 1px 4px;
  color: var(--color);
  cursor: pointer;
}
.send span:hover {
  --color: rgb(142, 142, 160);
  background: #e5e5e5;
}
</style>
